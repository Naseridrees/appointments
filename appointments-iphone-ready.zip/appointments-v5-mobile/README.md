# متابعة حجوزات المواعيد v3.1

التشغيل:
- A) 1-RUN-NOW.bat: نافذة بسيطة بدون ميزات الخلفية (لا بوت ولا قاعدة بيانات).
- B) 2-BUILD-EXE.bat: النسخة الكاملة (قاعدة SQLite + بوت واتساب + مهام خلفية + إشعارات). لازم إنترنت أول مرة.
- C) GitHub Actions: ارفع المجلد > Actions > build-exe.

## الملفات
- main.js: النافذة، الأيقونة بجانب الساعة، IPC، المهام المجدولة (نسخ احتياطي، تذكيرات، ملخص 8:00).
- db.js: قاعدة SQLite (محرك node:sqlite المدمج، بدون ترجمة native) (people, messages, contacts, drafts, optout, reminders, usage, audit, kv).
- bot.js: واتساب (جهاز مرتبط) + قرارات الرد + الحماية.
- ai.js: عميل Claude (مهلة، إعادة محاولة عند 429/5xx، عدّاد استهلاك).
- insights.js: تلخيص مجمّع بدون هويات/هواتف لتبويب "اسأل بياناتك".
- test/run.js: 21 اختباراً للقاعدة والبوت والذكاء (npm test، يحتاج Node 22+).
- app/index.html: الواجهة.

## ملاحظات
- أول تشغيل بعد التحديث: احذف node_modules وpackage-lock.json القديمين إن وُجدا ثم 2-BUILD-EXE.bat.
- واتساب غير رسمي (whatsapp-web.js): استخدم رقماً مخصصاً. الطريق الرسمي: WhatsApp Business Cloud API.
- مفتاح Claude API بيتحفظ مشفّراً بحساب ويندوز (تبويب الاحتمالات > قراءة الذكاء الاصطناعي).

- الاعتماديات بدون أي مكتبة native: يشتغل `npm install` على أي Node بدون Visual Studio. Electron 37 (فيه Node 22.16).

## تشغيل سريع للنسخة الكاملة بدون بناء مثبّت
افتح cmd داخل المجلد: `npm install` ثم `npm start`.
