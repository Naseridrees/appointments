/* قاعدة بيانات SQLite دائمة: data.db بمجلد بيانات التطبيق. لا حذف فعلي للأشخاص (تعليم محذوف فقط). */
const path=require('path'),fs=require('fs');
let db,dir;
const J=JSON.stringify,jd=o=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jerusalem'}).format(new Date(Date.now()+(o||0)*864e5));
/* SQLite المدمج (node:sqlite، Node 22.5+ / Electron 35+): لا مكتبات native ولا Visual Studio */
class Lite{constructor(f){const {DatabaseSync}=require('node:sqlite');this.d=new DatabaseSync(f)}
 pragma(s){this.d.exec('PRAGMA '+s)}exec(s){this.d.exec(s)}
 prepare(s){const st=this.d.prepare(s);return{run:(...a)=>st.run(...a),get:(...a)=>st.get(...a),all:(...a)=>st.all(...a)}}
 transaction(fn){return(...a)=>{this.d.exec('BEGIN');try{const r=fn(...a);this.d.exec('COMMIT');return r}catch(e){try{this.d.exec('ROLLBACK')}catch(_){}throw e}}}}
function open(d){
 dir=d;fs.mkdirSync(d,{recursive:true});
 db=new Lite(path.join(d,'data.db'));
 db.pragma('journal_mode=WAL');db.pragma('synchronous=NORMAL');
 db.exec(`
 CREATE TABLE IF NOT EXISTS people(id INTEGER PRIMARY KEY,json TEXT NOT NULL,updated INTEGER NOT NULL,deleted INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,chat TEXT NOT NULL,dir TEXT NOT NULL,body TEXT,at INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS ix_msg ON messages(chat,at);
 CREATE TABLE IF NOT EXISTS contacts(chat TEXT PRIMARY KEY,name TEXT,phone TEXT,first_at INTEGER,last_at INTEGER);
 CREATE TABLE IF NOT EXISTS drafts(id INTEGER PRIMARY KEY AUTOINCREMENT,chat TEXT,name TEXT,inbound TEXT,reply TEXT,intent TEXT,conf REAL,parsed TEXT,at INTEGER,state TEXT NOT NULL DEFAULT 'pending');
 CREATE TABLE IF NOT EXISTS optout(chat TEXT PRIMARY KEY,at INTEGER);
 CREATE TABLE IF NOT EXISTS reminders(person_id INTEGER NOT NULL,date TEXT NOT NULL,kind TEXT NOT NULL,at INTEGER NOT NULL,PRIMARY KEY(person_id,date,kind));
 CREATE TABLE IF NOT EXISTS usage(day TEXT NOT NULL,model TEXT NOT NULL,calls INTEGER NOT NULL DEFAULT 0,tin INTEGER NOT NULL DEFAULT 0,tout INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(day,model));
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at INTEGER NOT NULL,event TEXT NOT NULL,detail TEXT);
 CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT);`);
 db.prepare('INSERT OR IGNORE INTO kv(k,v) VALUES(?,?)').run('schema','1');
}
const tx=f=>db.transaction(f);
const getKv=(k,d)=>{const r=db.prepare('SELECT v FROM kv WHERE k=?').get(k);return r?r.v:d};
const setKv=(k,v)=>db.prepare('INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)').run(k,String(v));
function audit(event,detail){try{db.prepare('INSERT INTO audit(at,event,detail) VALUES(?,?,?)').run(Date.now(),String(event).slice(0,40),String(detail||'').slice(0,300))}catch(_){}}
const liveCount=()=>db.prepare('SELECT COUNT(*) n FROM people WHERE deleted=0').get().n;
function syncPeople(rows){
 if(!Array.isArray(rows))return false;
 const L=liveCount();
 if(!rows.length&&L>0){audit('sync_refused','قائمة فارغة مقابل '+L+' سجل');return false} // حماية من مسح القاعدة بالغلط
 const now=Date.now(),up=db.prepare('INSERT INTO people(id,json,updated,deleted) VALUES(?,?,?,0) ON CONFLICT(id) DO UPDATE SET json=excluded.json,updated=excluded.updated,deleted=0 WHERE people.json<>excluded.json OR people.deleted=1'),
  del=db.prepare('UPDATE people SET deleted=1,updated=? WHERE id=?');
 tx(()=>{const ids=new Set();for(const r of rows){if(!r||typeof r.id!=='number')continue;ids.add(r.id);up.run(r.id,J(r),now)}
  for(const x of db.prepare('SELECT id FROM people WHERE deleted=0').all())if(!ids.has(x.id))del.run(now,x.id)})();
 return true}
const loadPeople=()=>db.prepare('SELECT json FROM people WHERE deleted=0 ORDER BY id DESC').all().map(x=>{try{return JSON.parse(x.json)}catch(_){return null}}).filter(Boolean);
const last9=s=>String(s||'').replace(/[٠-٩]/g,c=>c.charCodeAt(0)-1632).replace(/\D/g,'').slice(-9);
const findByPhone=ph=>{const p=last9(ph);return p.length<9?[]:loadPeople().filter(r=>last9(r.phone)===p)};
const findWaiting=(ph,svc)=>findByPhone(ph).find(r=>r.status==='ينتظر'&&(r.service||'')===(svc||''))||null;
/* حالة الواجهة الكاملة (إعدادات، قوالب، سجل فحوصات...) لاسترجاعها إذا انمسح تخزين المتصفح */
function setLs(ls){if(!ls||typeof ls!=='object')return false;const o={};let n=0;
 for(const k of Object.keys(ls))if(/^bk_/.test(k)&&typeof ls[k]==='string'){o[k]=ls[k];n+=ls[k].length}
 if(n>2e7)return false;const has=!!(o.bk_tracker_v1||o.bk_cfg_v1);if(!has&&getKv('ls',''))return false;
 setKv('ls',J(o));return true}
const getLs=()=>{try{return JSON.parse(getKv('ls','{}'))}catch(_){return {}}};
/* واتساب */
const addMsg=(chat,d,body)=>db.prepare('INSERT INTO messages(chat,dir,body,at) VALUES(?,?,?,?)').run(chat,d,String(body||'').slice(0,2000),Date.now());
const history=(chat,n)=>db.prepare('SELECT dir,body FROM messages WHERE chat=? ORDER BY at DESC,id DESC LIMIT ?').all(chat,n).reverse();
function upsertContact(chat,name,phone){const n=Date.now();db.prepare('INSERT INTO contacts(chat,name,phone,first_at,last_at) VALUES(?,?,?,?,?) ON CONFLICT(chat) DO UPDATE SET name=CASE WHEN excluded.name<>\'\' THEN excluded.name ELSE contacts.name END,phone=excluded.phone,last_at=excluded.last_at').run(chat,name||'',phone||'',n,n)}
const recentConvs=n=>db.prepare('SELECT m.chat chat,c.name name,m.body body,m.dir dir,m.at at FROM messages m JOIN (SELECT chat,MAX(id) mid FROM messages GROUP BY chat ORDER BY mid DESC LIMIT ?) x ON m.id=x.mid LEFT JOIN contacts c ON c.chat=m.chat ORDER BY m.id DESC').all(n);
const addDraft=d=>db.prepare('INSERT INTO drafts(chat,name,inbound,reply,intent,conf,parsed,at) VALUES(?,?,?,?,?,?,?,?)').run(d.chat,d.name||'',d.inbound||'',d.reply||'',d.intent||'',+d.conf||0,J(d.parsed||{}),Date.now()).lastInsertRowid;
const getDraft=id=>db.prepare('SELECT * FROM drafts WHERE id=?').get(id);
const setDraft=(id,s)=>db.prepare('UPDATE drafts SET state=? WHERE id=?').run(s,id);
const pending=n=>db.prepare("SELECT id,chat,name,inbound,reply,intent,conf,at FROM drafts WHERE state='pending' ORDER BY id DESC LIMIT ?").all(n);
const countPending=()=>db.prepare("SELECT COUNT(*) n FROM drafts WHERE state='pending'").get().n;
const isOut=c=>!!db.prepare('SELECT 1 FROM optout WHERE chat=?').get(c);
const setOut=c=>db.prepare('INSERT OR REPLACE INTO optout(chat,at) VALUES(?,?)').run(c,Date.now());
const hasReminder=(id,date,kind)=>!!db.prepare('SELECT 1 FROM reminders WHERE person_id=? AND date=? AND kind=?').get(id,date,kind);
const markReminder=(id,date,kind)=>db.prepare('INSERT OR IGNORE INTO reminders(person_id,date,kind,at) VALUES(?,?,?,?)').run(id,date,kind,Date.now());
/* استهلاك الذكاء الاصطناعي */
const addUsage=(model,tin,tout)=>db.prepare('INSERT INTO usage(day,model,calls,tin,tout) VALUES(?,?,1,?,?) ON CONFLICT(day,model) DO UPDATE SET calls=calls+1,tin=tin+excluded.tin,tout=tout+excluded.tout').run(jd(0),String(model),+tin||0,+tout||0);
function usageSummary(){const q=(w,a)=>db.prepare('SELECT COALESCE(SUM(calls),0) c,COALESCE(SUM(tin),0) i,COALESCE(SUM(tout),0) o FROM usage WHERE '+w).get(a);return{today:q('day=?',jd(0)),d30:q('day>=?',jd(-30))}}
/* ملخص صباحي */
function digest(){const P=loadPeople(),t=jd(0),m=jd(1),b=P.filter(r=>r.status==='محجوز'),w=P.filter(r=>r.status==='ينتظر');
 return{today:b.filter(r=>r.date===t).length,tomorrow:b.filter(r=>r.date===m).length,waiting:w.length,urgent:w.filter(r=>r.urgent).length,pending:countPending()}}
/* نسخ احتياطية: يومية، آخر 14 + تنظيف رسائل أقدم من 90 يوم */
function backup(){
 try{const bd=path.join(dir,'backups');fs.mkdirSync(bd,{recursive:true});
  const f=path.join(bd,'data-'+jd(0)+'.db');if(!fs.existsSync(f))db.exec("VACUUM INTO '"+f.replace(/'/g,"''")+"'");
  fs.readdirSync(bd).filter(x=>/^data-.*\.db$/.test(x)).sort().slice(0,-14).forEach(x=>fs.unlinkSync(path.join(bd,x)));
  db.prepare('DELETE FROM messages WHERE at<?').run(Date.now()-90*864e5);db.prepare('DELETE FROM audit WHERE at<?').run(Date.now()-180*864e5);
  return f}catch(e){audit('backup_fail',e.message);return null}}
function info(){let bk='',sz=0;try{const bd=path.join(dir,'backups');bk=fs.readdirSync(bd).filter(x=>/^data-.*\.db$/.test(x)).sort().pop()||''}catch(_){}try{sz=fs.statSync(path.join(dir,'data.db')).size}catch(_){}
 const n=t=>db.prepare('SELECT COUNT(*) n FROM '+t).get().n;
 return{people:liveCount(),removed:n('people')-liveCount(),messages:n('messages'),contacts:n('contacts'),pending:countPending(),lastBackup:bk.replace(/^data-|\.db$/g,''),size:sz,dir,usage:usageSummary()}}
module.exports={open,getKv,setKv,audit,syncPeople,loadPeople,findByPhone,findWaiting,setLs,getLs,addMsg,history,upsertContact,recentConvs,addDraft,getDraft,setDraft,pending,countPending,isOut,setOut,hasReminder,markReminder,addUsage,usageSummary,digest,backup,info};
