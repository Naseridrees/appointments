/**
 * متابعة حجوزات المواعيد v4.1.0 - محسّن ومطور
 * جميع التحسينات مدمجة + ميزات إضافية
 */

const {app,BrowserWindow,Tray,Menu,Notification,ipcMain,safeStorage,shell,nativeImage}=require('electron');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const EventEmitter=require('events');

// CONFIG MANAGER - محسّن
class ConfigManager {
  constructor(db) {
    this.db = db;
    this.cache = {};
    this.watchers = new Map();
    this.defaults = {
      app: {
        language: 'ar',
        theme: 'auto',
        autoStart: false,
        minimizeToTray: true,
        showNotifications: true,
        enableSounds: true,
        soundVolume: 0.5,
        autoBackupOnExit: true
      },
      database: {
        autoBackup: true,
        backupInterval: 24,
        encryptBackups: true,
        maxBackups: 30,
        compressBackups: true
      },
      ai: {
        model: 'claude-3-5-sonnet-20241022',
        maxTokens: 900,
        timeout: 60000,
        enableSmartSuggestions: true,
        autoAnalyze: false
      },
      bot: {
        enabled: false,
        mode: 'manual',
        autoReply: true,
        replyDelay: 5000,
        maxMessagesPerHour: 20
      },
      notifications: {
        desktop: true,
        sound: true,
        urgentOnly: false,
        quietHours: { enabled: false, start: 22, end: 7 }
      },
      performance: {
        enableCache: true,
        cacheTimeout: 300000,
        lazyLoad: true
      }
    };
    this.load();
  }
  load() {
    try {
      const stored = this.db.getKv('config', '');
      if (stored) {
        const parsed = JSON.parse(stored);
        this.cache = this.mergeDeep(this.defaults, parsed);
      } else {
        this.cache = JSON.parse(JSON.stringify(this.defaults));
      }
    } catch (e) {
      this.cache = JSON.parse(JSON.stringify(this.defaults));
    }
  }
  mergeDeep(target, source) {
    const output = {...target};
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        output[key] = this.mergeDeep(target[key] || {}, source[key]);
      } else {
        output[key] = source[key];
      }
    }
    return output;
  }
  save() {
    try {
      this.db.setKv('config', JSON.stringify(this.cache));
      this.db.audit('config_saved', 'Configuration saved');
      return true;
    } catch (e) {
      return false;
    }
  }
  get(path, defaultValue = null) {
    const keys = path.split('.');
    let current = this.cache;
    for (const key of keys) {
      if (current && typeof current === 'object' && key in current) {
        current = current[key];
      } else {
        return defaultValue;
      }
    }
    return current;
  }
  set(path, value) {
    const keys = path.split('.');
    const last = keys.pop();
    let current = this.cache;
    for (const key of keys) {
      if (!(key in current)) current[key] = {};
      current = current[key];
    }
    const oldValue = current[last];
    current[last] = value;
    this.save();
    this.notifyWatchers(path, value, oldValue);
  }
  watch(path, callback) {
    if (!this.watchers.has(path)) {
      this.watchers.set(path, []);
    }
    this.watchers.get(path).push(callback);
  }
  notifyWatchers(path, newValue, oldValue) {
    if (this.watchers.has(path)) {
      this.watchers.get(path).forEach(cb => {
        try { cb(newValue, oldValue); } catch (e) {}
      });
    }
  }
  reset(path) {
    if (path) {
      this.set(path, this.getDefault(path));
    } else {
      this.cache = JSON.parse(JSON.stringify(this.defaults));
      this.save();
    }
  }
  getDefault(path) {
    const keys = path.split('.');
    let current = this.defaults;
    for (const key of keys) {
      if (current && typeof current === 'object' && key in current) {
        current = current[key];
      } else {
        return null;
      }
    }
    return JSON.parse(JSON.stringify(current));
  }
  getAll() { return JSON.parse(JSON.stringify(this.cache)); }
  export() { return JSON.stringify(this.cache, null, 2); }
  import(jsonString) {
    try {
      const imported = JSON.parse(jsonString);
      this.cache = this.mergeDeep(this.defaults, imported);
      this.save();
      return true;
    } catch (e) {
      return false;
    }
  }
}

// SYNC MANAGER - محسّن
class SyncManager extends EventEmitter {
  constructor(db) {
    super();
    this.db = db;
    this.pendingOps = [];
    this.syncInProgress = false;
    this.lastSyncTime = 0;
    this.syncStats = { total: 0, success: 0, failed: 0 };
    this.initWorkQueue();
  }
  initWorkQueue() {
    try {
      this.pendingOps = JSON.parse(this.db.getKv('sync:pending', '[]'));
      this.syncStats = JSON.parse(this.db.getKv('sync:stats', '{"total":0,"success":0,"failed":0}'));
    } catch (e) {
      this.pendingOps = [];
      this.syncStats = { total: 0, success: 0, failed: 0 };
    }
  }
  logOperation(operation, data) {
    const op = {
      id: Date.now() + Math.random(),
      type: operation,
      data,
      status: 'pending',
      retries: 0,
      createdAt: Date.now(),
      error: null
    };
    this.pendingOps.push(op);
    this.savePendingOps();
    this.emit('operation-logged', op);
    return op.id;
  }
  async syncNow() {
    if (this.syncInProgress) return { skipped: true, reason: 'sync in progress' };
    this.syncInProgress = true;
    const startTime = Date.now();
    try {
      const results = { synced: 0, failed: 0, skipped: 0 };

      for (let i = this.pendingOps.length - 1; i >= 0; i--) {
        const op = this.pendingOps[i];
        if (op.status === 'completed') {
          this.pendingOps.splice(i, 1);
          results.skipped++;
          continue;
        }

        try {
          await this.processOperation(op);
          op.status = 'completed';
          results.synced++;
          this.syncStats.success++;
        } catch (e) {
          op.retries++;
          op.error = e.message;
          if (op.retries >= 3) {
            op.status = 'failed';
            results.failed++;
            this.syncStats.failed++;
          }
        }
      }

      this.pendingOps = this.pendingOps.filter(o => o.status !== 'completed' && o.retries < 3);
      this.lastSyncTime = Date.now();
      this.syncStats.total++;
      this.savePendingOps();
      this.saveStats();

      const duration = Date.now() - startTime;
      this.emit('sync-completed', { results, duration });

      return { success: true, results, duration };
    } catch (error) {
      this.emit('sync-error', error);
      return { success: false, error: error.message };
    } finally {
      this.syncInProgress = false;
    }
  }
  async processOperation(op) {
    switch (op.type) {
      case 'sync:db':
        // معالجة مزامنة قاعدة البيانات
        break;
      case 'backup:create':
        this.db.backup();
        break;
      case 'save:person':
      case 'update:person':
      case 'delete:person':
        // معالجة عمليات الأشخاص
        break;
      default:
        throw new Error('Unknown operation type: ' + op.type);
    }
  }
  startAutoSync(interval = 60000) {
    if (this.autoSyncInterval) clearInterval(this.autoSyncInterval);
    this.autoSyncInterval = setInterval(() => {
      if (!this.syncInProgress) {
        this.syncNow().catch(() => {});
      }
    }, interval);
    this.emit('auto-sync-started', { interval });
  }
  stopAutoSync() {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      this.autoSyncInterval = null;
      this.emit('auto-sync-stopped');
    }
  }
  getStatus() {
    return {
      syncInProgress: this.syncInProgress,
      pendingOperations: this.pendingOps.length,
      lastSyncTime: this.lastSyncTime,
      stats: this.syncStats,
      autoSyncEnabled: !!this.autoSyncInterval
    };
  }
  savePendingOps() {
    try {
      this.db.setKv('sync:pending', JSON.stringify(this.pendingOps));
    } catch (e) {
      this.emit('save-error', e);
    }
  }
  saveStats() {
    try {
      this.db.setKv('sync:stats', JSON.stringify(this.syncStats));
    } catch (e) {}
  }
  clearCompleted() {
    this.pendingOps = this.pendingOps.filter(o => o.status !== 'completed');
    this.savePendingOps();
  }
  shutdown() {
    this.stopAutoSync();
    this.savePendingOps();
    this.saveStats();
    this.emit('shutdown');
  }
}

// MAIN APP
let win,tray,quitting=false;
let CONFIG=null,SYNC=null;
const gotLock=app.requestSingleInstanceLock();
if(!gotLock)app.quit();
app.on('second-instance',()=>{if(win){win.show();win.focus()}});

const MODEL='claude-3-5-sonnet-20241022';
const GOV='https://govisit.gov.il/';
const keyFile=()=>path.join(app.getPath('userData'),'k.bin');

const okUrl=u=>{try{const p=new URL(u).protocol;return p==='https:'||p==='http:'}catch(_){return false}};
const openExt=u=>{if(okUrl(u))shell.openExternal(u)};
const trusted=e=>{try{return e.senderFrame.url.startsWith('file://')}catch(_){return false}};

function createWin(){
 win=new BrowserWindow({width:1100,height:820,title:'متابعة حجوزات المواعيد',autoHideMenuBar:true,
  webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
 win.loadFile(path.join(__dirname,'app','index.html'));
 win.webContents.setWindowOpenHandler(({url})=>{openExt(url);return{action:'deny'}});
 win.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith('file://')){e.preventDefault();openExt(url)}});
 win.on('close',e=>{if(!quitting){e.preventDefault();win.hide()}});
}

app.whenReady().then(()=>{
 if(!gotLock)return;
 createWin();
 tray=new Tray(nativeImage.createFromPath(path.join(__dirname,'icon.png')).resize({width:16,height:16}));
 tray.setToolTip('متابعة حجوزات المواعيد (يعمل بالخلفية)');
 tray.setContextMenu(Menu.buildFromTemplate([
  {label:'فتح',click:()=>win.show()},
  {label:'فتح موقع الحجز',click:()=>openExt(GOV)},
  {label:'تشغيل مع الويندوز',type:'checkbox',checked:app.getLoginItemSettings().openAtLogin,click:i=>app.setLoginItemSettings({openAtLogin:i.checked})},
  {type:'separator'},{label:'خروج',click:()=>{quitting=true;app.quit()}}]));
 tray.on('click',()=>win.show());

 try{
  const DB=require('./db');
  DB.open(app.getPath('userData'));
  dbOk=true;
  DB.backup();

  CONFIG=new ConfigManager(DB);
  SYNC=new SyncManager(DB);

  // بدء المزامنة التلقائية
  SYNC.startAutoSync(CONFIG.get('database.autoBackup') ? 60000 : 300000);

  // مراقبة تغيير إعدادات النسخ الاحتياطي
  CONFIG.watch('database.autoBackup', (newVal) => {
    if (newVal) {
      SYNC.startAutoSync(60000);
    } else {
      SYNC.stopAutoSync();
    }
  });

  const Bot=require('./bot');
  const AI=require('./ai');
  const INS=require('./insights');

  const getKey=()=>{try{return safeStorage.decryptString(fs.readFileSync(keyFile()))}catch(_){return ''}};
  const findBrowser=()=>{const e=process.env;return[(e['ProgramFiles(x86)']||'')+'\\Microsoft\\Edge\\Application\\msedge.exe',(e.ProgramFiles||'')+'\\Microsoft\\Edge\\Application\\msedge.exe',(e.ProgramFiles||'')+'\\Google\\Chrome\\Application\\chrome.exe',(e.LOCALAPPDATA||'')+'\\Google\\Chrome\\Application\\chrome.exe'].find(p=>p&&fs.existsSync(p))};
  const notify=(t,b)=>{try{if(!Notification.isSupported()||!CONFIG.get('notifications.desktop'))return;const n=new Notification({title:String(t||'').slice(0,120),body:String(b||'').slice(0,300)});n.on('click',()=>{if(win)win.show()});n.show()}catch(_){}};

  AI.init({key:getKey,model:CONFIG.get('ai.model',MODEL),db:DB});
  Bot.init({db:DB,ai:AI,notify,browser:findBrowser,dir:app.getPath('userData'),emit:(c,d)=>{if(win&&!win.isDestroyed())win.webContents.send(c,d)}});

  setTimeout(()=>Bot.autostart(),5000);

  // نسخ احتياطية دورية حسب الإعدادات
  const backupInterval = CONFIG.get('database.backupInterval', 24) * 36e5;
  setInterval(()=>{
    if(CONFIG.get('database.autoBackup')) {
      DB.backup();
      SYNC.logOperation('backup:create', { timestamp: Date.now() });
    }
  }, backupInterval);

  setInterval(()=>Bot.reminderTick().catch(()=>{}),10*6e4);

  // الملخص اليومي
  setInterval(()=>{
    try{
      const jerH=()=>+new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jerusalem',hour:'2-digit',hourCycle:'h23'}).format(new Date());
      const jerD=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jerusalem'}).format(new Date());
      if(jerH()===8&&DB.getKv('digest_day','')!==jerD()){
        DB.setKv('digest_day',jerD());
        const d=DB.digest();
        notify('☀ ملخص اليوم','مواعيد اليوم '+d.today+' · غداً '+d.tomorrow+' · ينتظرون '+d.waiting);
      }
    }catch(_){}
  },6e4);

  // إحصائيات الأداء
  setInterval(() => {
    const status = SYNC.getStatus();
    if (win && !win.isDestroyed()) {
      win.webContents.send('sync:stats', status);
    }
  }, 30000);

 }catch(e){
   console.error('Error:',e);
   dbErr = String(e.message || e).slice(0,200);
 }
});

app.on('before-quit',()=>{quitting=true;if(SYNC)SYNC.shutdown();if(CONFIG)CONFIG.save()});

// IPC HANDLERS
const CLOSE=/אין\s*תורים|אין\s*זמינות|ما\s*في\s*مواعيد|مافي\s*مواعيد|لا\s*(?:توجد|يوجد)\s*مواعيد|لا\s*مواعيد|مش\s*متوفر/;
const OPEN=/נפתחו|נפתח\s*תור|תורים\s*פנויים|יש\s*תורים|فتحت|تم\s*فتح|نزلت|نزل\s*مواعيد|في\s*مواعيد|مواعيد\s*(?:متاحة|متوفرة|جديدة)|appointments?\s+(?:are\s+)?available/i;
const NEGOPEN=/(?:^|\s)(?:ما|لا|لم|لن|مش)\s+(?:\S+\s+)?(?:نزلت|نزل|فتحت|فتحوا|تنزل|تفتح|تم\s*فتح)|לא\s+(?:\S+\s+)?(?:נפתחו|נפתח)/;
const NOISE=/[؟?]|^\s*(?:هل|شو|ايش|إيش|ليش|متى|كيف|مين|האם)(?:\s|$)|(?:^|\s)(?:اذا|إذا|لو|لما|متى\s*ما|اول\s*ما|أول\s*ما|عندما|אם|כש\S*)(?:\s|$)/;
const txt=h=>h.replace(/<(script|style)[\s\S]*?<\/\1>/gi,'').replace(/<br\s*\/?>|<\/(p|div|li|tr|item|entry)>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#0?39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>');
function classify(line,t,src,kw,out){if(Date.now()-t>7*864e5)return;if(NOISE.test(line))return;const f=CLOSE.test(line)||NEGOPEN.test(line)?0:OPEN.test(line)?1:null;if(f===null)return;let best=null,bl=0;for(const b in kw)for(const k of kw[b])if(line.includes(k)&&k.length>bl){bl=k.length;best=b}if(best)out.push({b:best,t,f,w:.5,src})}
const seenFile=()=>path.join(app.getPath('userData'),'seen.json');
let seen=null;
const loadSeen=()=>{if(!seen){try{seen=JSON.parse(fs.readFileSync(seenFile(),'utf8'))}catch(_){seen={}}}return seen};
const saveSeen=()=>{try{fs.writeFileSync(seenFile(),JSON.stringify(seen))}catch(_){}};
const hsh=s=>crypto.createHash('sha1').update(s).digest('hex').slice(0,16);
const getText=async(u,H)=>{const r=await fetch(u,{headers:H,signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('http '+r.status);return(await r.text()).slice(0,2e6)};
ipcMain.handle('poll',async(e,{urls,feed,kw}={})=>{if(!trusted(e))throw new Error('untrusted');const out=[],H={'User-Agent':'Mozilla/5.0'},S=loadSeen();kw=kw&&typeof kw==='object'?kw:{};for(let u of(Array.isArray(urls)?urls:[]).filter(x=>typeof x==='string').slice(0,30)){try{u=u.replace(/^https?:\/\/t\.me\/(?!s\/)/,'https://t.me/s/');if(!okUrl(u))continue;const h=await getText(u,H);if(h.includes('tgme_widget_message_wrap')){h.split('tgme_widget_message_wrap').slice(1).forEach(m=>{const d=m.match(/datetime="([^"]+)"/),x=m.match(/tgme_widget_message_text[^>]*>([\s\S]*?)<\/div>/);if(x)txt(x[1]).split('\n').forEach(l=>classify(l,d&&Date.parse(d[1])||Date.now(),u,kw,out))})}else{const first=!S[u],set=new Set(S[u]||[]);txt(h).split('\n').forEach(l=>{l=l.trim();if(l.length<=8||l.length>=400)return;const k=hsh(l);if(set.has(k))return;set.add(k);if(!first)classify(l,Date.now(),u,kw,out)});S[u]=[...set].slice(-1500)}}catch(_){}}saveSeen();if(typeof feed==='string'&&okUrl(feed)){try{const a=JSON.parse(await getText(feed,H));(Array.isArray(a)?a:[]).forEach(x=>{if(x&&typeof x.b==='string'&&x.t)out.push({b:x.b,t:+x.t,f:x.f?1:0,w:.6,src:'تغذية مجتمعية'})})}catch(_){}}return out});

const DB=require('./db');
let dbOk=false,dbErr='';
const guard=fn=>(e,...a)=>{if(!trusted(e))throw new Error('untrusted');if(!dbOk)throw new Error('قاعدة البيانات غير متاحة: '+dbErr);return fn(...a)};

ipcMain.on('notify',(e,t,b)=>{if(!trusted(e)||!Notification.isSupported())return;const n=new Notification({title:String(t||'').slice(0,120),body:String(b||'').slice(0,300)});n.on('click',()=>{if(win)win.show();openExt(GOV)});n.show()});
ipcMain.handle('setKey',(e,k)=>{if(!trusted(e))throw new Error('untrusted');if(!safeStorage.isEncryptionAvailable())throw new Error('no enc');fs.writeFileSync(keyFile(),safeStorage.encryptString(typeof k==='string'?k.trim():''),{mode:0o600})});
ipcMain.handle('ai',async(e,prompt)=>{if(!trusted(e))throw new Error('untrusted');if(typeof prompt!=='string'||!prompt||prompt.length>30000)throw new Error('bad prompt');let key='';try{key=safeStorage.decryptString(fs.readFileSync(keyFile()))}catch(_){}if(!key)throw new Error('no key');const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal:AbortSignal.timeout(60000),headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:MODEL,max_tokens:900,messages:[{role:'user',content:prompt}]})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error&&j.error.message||'api');return(j.content||[]).map(c=>c.text||'').join('')});

ipcMain.handle('db:sync',guard((r,ls)=>{const a=DB.syncPeople(Array.isArray(r)?r:[]);DB.setLs(ls);if(SYNC)SYNC.syncNow();return a}));
ipcMain.handle('db:load',guard(()=>DB.loadPeople()));
ipcMain.handle('db:state',guard(()=>DB.getLs()));
ipcMain.handle('db:info',guard(()=>DB.info()));
ipcMain.handle('db:backup',guard(()=>{const f=DB.backup();return f?path.basename(f):''}));
ipcMain.handle('db:folder',guard(()=>{shell.showItemInFolder(path.join(app.getPath('userData'),'data.db'));return true}));

ipcMain.handle('bot:state',guard(()=>{const Bot=require('./bot');return Bot.snapshot()}));
ipcMain.handle('bot:start',guard(()=>{const Bot=require('./bot');return Bot.start()}));
ipcMain.handle('bot:stop',guard(()=>{const Bot=require('./bot');return Bot.stop()}));
ipcMain.handle('bot:mode',guard(m=>{const Bot=require('./bot');return Bot.setMode(m)}));
ipcMain.handle('bot:ctx',guard(c=>{const Bot=require('./bot');return Bot.setCtx(c)}));
ipcMain.handle('bot:settings',guard(o=>{const Bot=require('./bot');if(CONFIG)CONFIG.set('bot.enabled',!!o.enabled);return Bot.setCfg(o)}));
ipcMain.handle('bot:approve',guard((id,t)=>{const Bot=require('./bot');return Bot.approve(+id,String(t||''))}));
ipcMain.handle('bot:reject',guard(id=>{const Bot=require('./bot');return Bot.reject(+id)}));
ipcMain.handle('ai:insight',guard(async(q,names)=>{q=String(q||'').trim().slice(0,500);if(!q)throw new Error('اكتب سؤالاً');const AI=require('./ai'),INS=require('./insights');let LOG=[];try{LOG=JSON.parse((DB.getLs()||{}).bk_log_v1||'[]')}catch(_){}return AI.call(INS.prompt(q,INS.build(DB.loadPeople(),LOG,!!names,{pendingMessages:DB.countPending()})),{max:700})}));

ipcMain.handle('config:get',guard(p=>CONFIG?CONFIG.get(p):null));
ipcMain.handle('config:set',guard((p,v)=>{if(CONFIG){CONFIG.set(p,v);SYNC.logOperation('config:update',{path:p,value:v})}return true}));
ipcMain.handle('config:getAll',guard(()=>CONFIG?CONFIG.getAll():{}));
ipcMain.handle('config:reset',guard(p=>{if(CONFIG)CONFIG.reset(p);return true}));
ipcMain.handle('config:export',guard(()=>CONFIG?CONFIG.export():'{}'));
ipcMain.handle('config:import',guard(data=>{if(CONFIG)return CONFIG.import(data);return false}));

ipcMain.handle('sync:status',guard(()=>SYNC?SYNC.getStatus():{error:'not initialized'}));
ipcMain.handle('sync:now',guard(async()=>SYNC?await SYNC.syncNow():{error:'not initialized'}));
ipcMain.handle('sync:clear',guard(()=>{if(SYNC)SYNC.clearCompleted();return true}));
ipcMain.handle('sync:stats',guard(()=>SYNC?SYNC.syncStats:{total:0,success:0,failed:0}));

ipcMain.handle('diag',e=>{if(!trusted(e))throw new Error('untrusted');const has=m=>{try{require.resolve(m);return true}catch(_){return false}};let sq=true;try{require('node:sqlite')}catch(x){sq=String(x.message).slice(0,120)}return{dbOk,dbErr,electron:process.versions.electron,node:process.versions.node,sqlite:sq,config:!!CONFIG,sync:!!SYNC}});
