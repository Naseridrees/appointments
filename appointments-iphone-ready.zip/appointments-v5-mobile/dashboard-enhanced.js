/**
 * لوحة التحكم المحسّنة v4.1.0
 * Dashboard مع إحصائيات مرئية وKPIs محسّنة
 */

// معالج لوحة التحكم المحسّنة
function renderEnhancedDashboard(data) {
    const {
        today,
        tomorrow,
        waiting,
        urgent,
        totalBooked,
        successRate,
        avgWaitDays,
        checksToday,
        bookingsToday
    } = data;

    return `
        <div class="dashboard-grid">
            <!-- KPI Cards -->
            <div class="kpi-card animate-in">
                <div class="title">ينتظرون موعداً</div>
                <div class="value">${waiting}</div>
                <div class="trend up">
                    <span>↑ ${urgent} مستعجل</span>
                </div>
                <div class="subtitle">من إجمالي ${waiting + totalBooked} حالة</div>
            </div>

            <div class="kpi-card animate-in" style="animation-delay: 0.1s">
                <div class="title">مواعيد اليوم</div>
                <div class="value">${today}</div>
                <div class="trend ${today > 0 ? 'up' : ''}">
                    <span>غداً: ${tomorrow}</span>
                </div>
                <div class="subtitle">محجوز ومؤكد</div>
            </div>

            <div class="kpi-card animate-in" style="animation-delay: 0.2s">
                <div class="title">معدل النجاح</div>
                <div class="value">${successRate}%</div>
                <div class="trend ${successRate >= 70 ? 'up' : 'down'}">
                    <span>${successRate >= 70 ? '↑ ممتاز' : '↓ يحتاج تحسين'}</span>
                </div>
                <div class="mini-chart">
                    ${generateMiniChart(7)}
                </div>
            </div>

            <div class="kpi-card animate-in" style="animation-delay: 0.3s">
                <div class="title">متوسط الانتظار</div>
                <div class="value">${avgWaitDays}</div>
                <div class="subtitle">يوم</div>
                <div class="progress-bar" style="margin-top: 12px;">
                    <div class="fill" style="width: ${Math.min(avgWaitDays * 10, 100)}%"></div>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="quick-stat">
                <div class="number">${checksToday}</div>
                <div class="label">فحوصات اليوم</div>
            </div>
            <div class="quick-stat">
                <div class="number">${bookingsToday}</div>
                <div class="label">حجوزات اليوم</div>
            </div>
            <div class="quick-stat">
                <div class="number">${Math.round((bookingsToday/checksToday)*100) || 0}%</div>
                <div class="label">كفاءة الحجز</div>
            </div>
        </div>

        <!-- Notifications -->
        <div style="margin-top: 24px;">
            <h3 style="margin-bottom: 12px;">التنبيهات والإشعارات</h3>
            ${renderNotifications(data)}
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <button class="btn-primary" onclick="quickCheck()">🔍 فحص سريع</button>
            <button class="btn-primary" onclick="sendReminders()">📨 إرسال تذكيرات</button>
            <button class="btn-secondary" onclick="generateReport()">📊 تقرير اليوم</button>
            <button class="btn-secondary" onclick="createBackup()">💾 نسخ احتياطي</button>
        </div>
    `;
}

function generateMiniChart(days) {
    let html = '';
    for (let i = 0; i < days; i++) {
        const height = Math.random() * 100;
        html += `<div class="bar" style="height: ${height}%"></div>`;
    }
    return html;
}

function renderNotifications(data) {
    const notifications = [];
    
    if (data.urgent > 0) {
        notifications.push({
            type: 'error',
            icon: '⚠️',
            title: 'حالات مستعجلة',
            message: `لديك ${data.urgent} حالة مستعجلة تحتاج متابعة فورية`,
            time: 'الآن'
        });
    }
    
    if (data.today > 0) {
        notifications.push({
            type: 'warning',
            icon: '📅',
            title: 'مواعيد اليوم',
            message: `${data.today} موعد اليوم، تأكد من التذكيرات`,
            time: 'منذ ساعة'
        });
    }
    
    if (data.successRate < 50) {
        notifications.push({
            type: 'warning',
            icon: '📉',
            title: 'معدل نجاح منخفض',
            message: 'معدل النجاح أقل من 50%، راجع استراتيجية الفحص',
            time: 'منذ 3 ساعات'
        });
    }
    
    if (notifications.length === 0) {
        notifications.push({
            type: 'info',
            icon: '✅',
            title: 'كل شيء على ما يرام',
            message: 'لا توجد تنبيهات حالياً',
            time: 'الآن'
        });
    }
    
    return notifications.map(n => `
        <div class="notification-card ${n.type}">
            <div class="icon">${n.icon}</div>
            <div class="content">
                <div class="title">${n.title}</div>
                <div class="message">${n.message}</div>
                <div class="time">${n.time}</div>
            </div>
        </div>
    `).join('');
}

// صفحة الإعدادات المحسّنة
function renderEnhancedSettings() {
    return `
        <div class="settings-container">
            <!-- Sidebar Navigation -->
            <div class="settings-sidebar">
                <div class="settings-nav-item active" data-section="general">
                    <span class="icon">⚙️</span>
                    <span>عام</span>
                </div>
                <div class="settings-nav-item" data-section="appearance">
                    <span class="icon">🎨</span>
                    <span>المظهر</span>
                </div>
                <div class="settings-nav-item" data-section="notifications">
                    <span class="icon">🔔</span>
                    <span>الإشعارات</span>
                </div>
                <div class="settings-nav-item" data-section="ai">
                    <span class="icon">🤖</span>
                    <span>الذكاء الاصطناعي</span>
                </div>
                <div class="settings-nav-item" data-section="whatsapp">
                    <span class="icon">💬</span>
                    <span>واتساب</span>
                </div>
                <div class="settings-nav-item" data-section="database">
                    <span class="icon">💾</span>
                    <span>قاعدة البيانات</span>
                </div>
                <div class="settings-nav-item" data-section="performance">
                    <span class="icon">⚡</span>
                    <span>الأداء</span>
                </div>
                <div class="settings-nav-item" data-section="security">
                    <span class="icon">🔒</span>
                    <span>الأمان</span>
                </div>
            </div>

            <!-- Settings Content -->
            <div class="settings-content" id="settings-content">
                ${renderGeneralSettings()}
            </div>
        </div>
    `;
}

function renderGeneralSettings() {
    return `
        <div class="settings-section">
            <div class="settings-section-title">
                <span>⚙️</span>
                <span>الإعدادات العامة</span>
            </div>
            
            <div class="settings-row">
                <div class="settings-field">
                    <label>اللغة</label>
                    <select id="language">
                        <option value="ar">العربية</option>
                        <option value="he">עברית</option>
                        <option value="en">English</option>
                    </select>
                    <span class="description">لغة واجهة التطبيق</span>
                </div>
                
                <div class="settings-field">
                    <label>البدء التلقائي مع Windows</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="autoStart">
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="description">تشغيل التطبيق تلقائياً عند بدء النظام</span>
                </div>
            </div>
            
            <div class="settings-row">
                <div class="settings-field">
                    <label>التصغير للشريط</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="minimizeToTray" checked>
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="description">إخفاء النافذة بدلاً من الإغلاق</span>
                </div>
                
                <div class="settings-field">
                    <label>الأصوات</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="enableSounds" checked>
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="description">تفعيل أصوات التنبيهات</span>
                </div>
            </div>
        </div>

        <div class="settings-section">
            <div class="settings-section-title">
                <span>🔊</span>
                <span>الأصوات والتنبيهات</span>
            </div>
            
            <div class="settings-row">
                <div class="settings-field">
                    <label>مستوى الصوت</label>
                    <input type="range" id="soundVolume" min="0" max="100" value="50">
                    <span class="description">من 0 إلى 100</span>
                </div>
                
                <div class="settings-field">
                    <label>اختبار الصوت</label>
                    <button class="btn-secondary" onclick="testSound()">🔊 تشغيل</button>
                    <span class="description">اختبار صوت التنبيه</span>
                </div>
            </div>
        </div>

        <div class="action-buttons">
            <button class="btn-primary" onclick="saveSettings()">💾 حفظ التغييرات</button>
            <button class="btn-secondary" onclick="resetSettings()">↺ استعادة الافتراضي</button>
            <button class="btn-secondary" onclick="exportSettings()">📤 تصدير الإعدادات</button>
        </div>
    `;
}

function renderAppearanceSettings() {
    return `
        <div class="settings-section">
            <div class="settings-section-title">
                <span>🎨</span>
                <span>المظهر والواجهة</span>
            </div>
            
            <div class="settings-row">
                <div class="settings-field">
                    <label>الثيم</label>
                    <select id="theme">
                        <option value="auto">تلقائي (حسب النظام)</option>
                        <option value="light">فاتح</option>
                        <option value="dark">داكن</option>
                    </select>
                    <span class="description">المظهر العام للتطبيق</span>
                </div>
                
                <div class="settings-field">
                    <label>حجم الخط</label>
                    <input type="number" id="fontSize" min="12" max="20" value="16">
                    <span class="description">من 12 إلى 20 بكسل</span>
                </div>
            </div>

            <div class="settings-row">
                <div class="settings-field">
                    <label>الصفحة الرئيسية</label>
                    <select id="homepage">
                        <option value="dash">لوحة التحكم</option>
                        <option value="fast">الوضع السريع</option>
                        <option value="check">تفقّد الفرع</option>
                        <option value="all">الكل</option>
                    </select>
                    <span class="description">الصفحة التي تفتح عند التشغيل</span>
                </div>
                
                <div class="settings-field">
                    <label>إخفاء أرقام الهويات</label>
                    <label class="toggle-switch">
                        <input type="checkbox" id="hideIds">
                        <span class="toggle-slider"></span>
                    </label>
                    <span class="description">إظهار النقاط بدلاً من الأرقام</span>
                </div>
            </div>
        </div>

        <div class="action-buttons">
            <button class="btn-primary" onclick="saveSettings()">💾 حفظ التغييرات</button>
        </div>
    `;
}

// دوال الإجراءات
function quickCheck() {
    console.log('Quick check initiated');
    // تنفيذ الفحص السريع
}

function sendReminders() {
    console.log('Sending reminders');
    // إرسال التذكيرات
}

function generateReport() {
    console.log('Generating report');
    // إنشاء تقرير
}

function createBackup() {
    console.log('Creating backup');
    // إنشاء نسخة احتياطية
}

function saveSettings() {
    console.log('Saving settings');
    // حفظ الإعدادات
}

function resetSettings() {
    if (confirm('هل تريد استعادة الإعدادات الافتراضية؟')) {
        console.log('Resetting settings');
        // استعادة الإعدادات
    }
}

function exportSettings() {
    console.log('Exporting settings');
    // تصدير الإعدادات
}

function testSound() {
    console.log('Testing sound');
    // اختبار الصوت
}

// معالج تبديل أقسام الإعدادات
document.addEventListener('click', function(e) {
    const navItem = e.target.closest('.settings-nav-item');
    if (navItem) {
        // إزالة active من الكل
        document.querySelectorAll('.settings-nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // إضافة active للعنصر المحدد
        navItem.classList.add('active');
        
        // تحديث المحتوى
        const section = navItem.dataset.section;
        updateSettingsContent(section);
    }
});

function updateSettingsContent(section) {
    const content = document.getElementById('settings-content');
    if (!content) return;
    
    switch(section) {
        case 'general':
            content.innerHTML = renderGeneralSettings();
            break;
        case 'appearance':
            content.innerHTML = renderAppearanceSettings();
            break;
        // ... المزيد من الأقسام
        default:
            content.innerHTML = '<p>قريباً...</p>';
    }
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        renderEnhancedDashboard,
        renderEnhancedSettings
    };
}
