/* عميل Claude مشترك: إعادة محاولة، مهلة، عدّاد استهلاك */
let C={};const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const init=o=>{C=o};
async function call(prompt,{max=900,retries=2}={}){
 const key=C.key();if(!key)throw new Error('no key');
 let last;
 for(let i=0;i<=retries;i++){
  let retry=false;
  try{
   const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal:AbortSignal.timeout(60000),headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:C.model,max_tokens:max,messages:[{role:'user',content:String(prompt)}]})});
   const j=await r.json().catch(()=>({}));
   if(r.ok){try{if(C.db&&j.usage)C.db.addUsage(C.model,j.usage.input_tokens,j.usage.output_tokens)}catch(_){}return(j.content||[]).map(c=>c.text||'').join('')}
   last=new Error((j.error&&j.error.message)||'api '+r.status);retry=r.status===429||r.status>=500;
  }catch(e){last=e;retry=e.name==='TimeoutError'||e.name==='AbortError'||e.name==='TypeError'}
  if(!retry||i===retries)break;await sleep(1500*(i+1));
 }
 throw last}
async function json(prompt,o){const t=await call(prompt,o),m=t.match(/\{[\s\S]*\}/);if(!m)throw new Error('رد غير مفهوم من الذكاء');return JSON.parse(m[0])}
module.exports={init,call,json};
