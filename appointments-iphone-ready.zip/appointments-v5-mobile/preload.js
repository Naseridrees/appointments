const {contextBridge,ipcRenderer}=require('electron');
const iv=c=>(...a)=>ipcRenderer.invoke(c,...a);
contextBridge.exposeInMainWorld('desk',{
 pollSources:o=>ipcRenderer.invoke('poll',o),ai:p=>ipcRenderer.invoke('ai',p),
 setKey:k=>ipcRenderer.invoke('setKey',k),notify:(t,b)=>ipcRenderer.send('notify',t,b),
 dbSync:iv('db:sync'),dbLoad:iv('db:load'),stateLoad:iv('db:state'),dbInfo:iv('db:info'),dbBackup:iv('db:backup'),dbFolder:iv('db:folder'),
 insight:iv('ai:insight'),diag:iv('diag'),
 bot:{state:iv('bot:state'),start:iv('bot:start'),stop:iv('bot:stop'),mode:iv('bot:mode'),ctx:iv('bot:ctx'),settings:iv('bot:settings'),approve:iv('bot:approve'),reject:iv('bot:reject')},
 onBotUpdate:cb=>ipcRenderer.on('bot:update',(_e,d)=>cb(d)),onBotAdd:cb=>ipcRenderer.on('bot:add',(_e,d)=>cb(d))});
