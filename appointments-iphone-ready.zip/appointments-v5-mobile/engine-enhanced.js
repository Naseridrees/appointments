/**
 * المحرك المحسّن v4.1.0
 * Enhanced Engine with Performance Optimizations
 */

class EnhancedEngine {
    constructor() {
        this.cache = new Map();
        this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
        this.workers = [];
        this.taskQueue = [];
        this.isProcessing = false;
        this.metrics = {
            totalOperations: 0,
            successfulOperations: 0,
            failedOperations: 0,
            avgResponseTime: 0,
            cacheHits: 0,
            cacheMisses: 0
        };
    }

    // Cache Management
    getCached(key) {
        const cached = this.cache.get(key);
        if (!cached) {
            this.metrics.cacheMisses++;
            return null;
        }

        if (Date.now() - cached.timestamp > this.cacheTimeout) {
            this.cache.delete(key);
            this.metrics.cacheMisses++;
            return null;
        }

        this.metrics.cacheHits++;
        return cached.data;
    }

    setCache(key, data) {
        this.cache.set(key, {
            data,
            timestamp: Date.now()
        });

        // تنظيف الذاكرة المؤقتة إذا زاد حجمها
        if (this.cache.size > 1000) {
            const oldestKey = this.cache.keys().next().value;
            this.cache.delete(oldestKey);
        }
    }

    clearCache(pattern) {
        if (!pattern) {
            this.cache.clear();
            return;
        }

        for (const key of this.cache.keys()) {
            if (key.includes(pattern)) {
                this.cache.delete(key);
            }
        }
    }

    // Task Queue Management
    async addTask(task, priority = 0) {
        return new Promise((resolve, reject) => {
            this.taskQueue.push({
                task,
                priority,
                resolve,
                reject,
                addedAt: Date.now()
            });

            // ترتيب حسب الأولوية
            this.taskQueue.sort((a, b) => b.priority - a.priority);

            if (!this.isProcessing) {
                this.processTasks();
            }
        });
    }

    async processTasks() {
        if (this.isProcessing || this.taskQueue.length === 0) {
            return;
        }

        this.isProcessing = true;

        while (this.taskQueue.length > 0) {
            const item = this.taskQueue.shift();
            const startTime = Date.now();

            try {
                const result = await item.task();
                item.resolve(result);

                this.metrics.successfulOperations++;
                this.updateAvgResponseTime(Date.now() - startTime);
            } catch (error) {
                item.reject(error);
                this.metrics.failedOperations++;
            }

            this.metrics.totalOperations++;
        }

        this.isProcessing = false;
    }

    updateAvgResponseTime(responseTime) {
        const total = this.metrics.totalOperations;
        const currentAvg = this.metrics.avgResponseTime;
        this.metrics.avgResponseTime = ((currentAvg * (total - 1)) + responseTime) / total;
    }

    // Performance Monitoring
    getMetrics() {
        return {
            ...this.metrics,
            cacheSize: this.cache.size,
            cacheHitRate: this.metrics.cacheHits / 
                (this.metrics.cacheHits + this.metrics.cacheMisses) * 100 || 0,
            successRate: this.metrics.successfulOperations / 
                this.metrics.totalOperations * 100 || 0,
            queueLength: this.taskQueue.length
        };
    }

    resetMetrics() {
        this.metrics = {
            totalOperations: 0,
            successfulOperations: 0,
            failedOperations: 0,
            avgResponseTime: 0,
            cacheHits: 0,
            cacheMisses: 0
        };
    }

    // Batch Operations
    async batchProcess(items, processor, batchSize = 10) {
        const results = [];
        
        for (let i = 0; i < items.length; i += batchSize) {
            const batch = items.slice(i, i + batchSize);
            const batchResults = await Promise.all(
                batch.map(item => processor(item).catch(e => ({ error: e })))
            );
            results.push(...batchResults);
        }

        return results;
    }

    // Data Compression
    compress(data) {
        try {
            const str = JSON.stringify(data);
            // تحويل لـ base64 كبديل بسيط للضغط
            return btoa(encodeURIComponent(str));
        } catch (e) {
            return data;
        }
    }

    decompress(compressed) {
        try {
            const str = decodeURIComponent(atob(compressed));
            return JSON.parse(str);
        } catch (e) {
            return compressed;
        }
    }

    // Memory Management
    getMemoryUsage() {
        if (typeof performance !== 'undefined' && performance.memory) {
            return {
                used: performance.memory.usedJSHeapSize,
                total: performance.memory.totalJSHeapSize,
                limit: performance.memory.jsHeapSizeLimit,
                percentage: (performance.memory.usedJSHeapSize / 
                    performance.memory.jsHeapSizeLimit * 100).toFixed(2)
            };
        }
        return null;
    }

    optimizeMemory() {
        // تنظيف الذاكرة المؤقتة
        this.clearCache();
        
        // إفراغ قائمة المهام المكتملة
        this.taskQueue = this.taskQueue.filter(t => t.status !== 'completed');
        
        // تشغيل garbage collector إذا كان متاحاً
        if (global.gc) {
            global.gc();
        }
    }
}

class SmartScheduler {
    constructor() {
        this.jobs = new Map();
        this.intervals = new Map();
    }

    schedule(name, fn, interval, options = {}) {
        const {
            immediate = false,
            maxRetries = 3,
            onError = null
        } = options;

        if (this.jobs.has(name)) {
            this.cancel(name);
        }

        let retries = 0;

        const wrappedFn = async () => {
            try {
                await fn();
                retries = 0; // إعادة تعيين عند النجاح
            } catch (error) {
                retries++;
                if (onError) {
                    onError(error, retries);
                }

                if (retries >= maxRetries) {
                    console.error(`Job ${name} failed after ${maxRetries} retries`);
                    this.cancel(name);
                }
            }
        };

        if (immediate) {
            wrappedFn();
        }

        const intervalId = setInterval(wrappedFn, interval);
        
        this.jobs.set(name, {
            fn: wrappedFn,
            interval,
            intervalId,
            startedAt: Date.now()
        });

        return name;
    }

    cancel(name) {
        const job = this.jobs.get(name);
        if (job) {
            clearInterval(job.intervalId);
            this.jobs.delete(name);
            return true;
        }
        return false;
    }

    cancelAll() {
        for (const name of this.jobs.keys()) {
            this.cancel(name);
        }
    }

    getStatus() {
        const jobs = [];
        for (const [name, job] of this.jobs.entries()) {
            jobs.push({
                name,
                interval: job.interval,
                uptime: Date.now() - job.startedAt
            });
        }
        return jobs;
    }
}

class DataValidator {
    static validatePerson(person) {
        const errors = [];

        if (!person.name || person.name.trim().length < 2) {
            errors.push('الاسم مطلوب ويجب أن يكون أكثر من حرفين');
        }

        if (person.phone && !this.validatePhone(person.phone)) {
            errors.push('رقم الهاتف غير صحيح');
        }

        if (person.idn && !this.validateID(person.idn)) {
            errors.push('رقم الهوية غير صحيح');
        }

        if (person.date && !this.validateDate(person.date)) {
            errors.push('التاريخ غير صحيح');
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }

    static validatePhone(phone) {
        const cleaned = phone.replace(/\D/g, '');
        return cleaned.length >= 9 && cleaned.length <= 13;
    }

    static validateID(idn) {
        const cleaned = idn.replace(/\D/g, '');
        if (cleaned.length !== 9) return false;

        // تحقق Luhn للهوية الإسرائيلية
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            let digit = parseInt(cleaned[i]);
            if (i % 2 === 1) {
                digit *= 2;
                if (digit > 9) digit -= 9;
            }
            sum += digit;
        }

        return sum % 10 === 0;
    }

    static validateDate(dateStr) {
        const date = new Date(dateStr);
        return date instanceof Date && !isNaN(date);
    }
}

class PerformanceMonitor {
    constructor() {
        this.marks = new Map();
        this.measures = [];
    }

    mark(name) {
        this.marks.set(name, Date.now());
    }

    measure(name, startMark, endMark) {
        const start = this.marks.get(startMark);
        const end = endMark ? this.marks.get(endMark) : Date.now();

        if (!start) {
            console.warn(`Start mark ${startMark} not found`);
            return null;
        }

        const duration = end - start;
        this.measures.push({
            name,
            duration,
            timestamp: Date.now()
        });

        return duration;
    }

    getMeasures(name) {
        if (name) {
            return this.measures.filter(m => m.name === name);
        }
        return this.measures;
    }

    getStats(name) {
        const measures = this.getMeasures(name);
        if (measures.length === 0) return null;

        const durations = measures.map(m => m.duration);
        const sum = durations.reduce((a, b) => a + b, 0);
        const avg = sum / durations.length;
        const min = Math.min(...durations);
        const max = Math.max(...durations);

        return {
            count: measures.length,
            avg,
            min,
            max,
            total: sum
        };
    }

    clear() {
        this.marks.clear();
        this.measures = [];
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        EnhancedEngine,
        SmartScheduler,
        DataValidator,
        PerformanceMonitor
    };
}
